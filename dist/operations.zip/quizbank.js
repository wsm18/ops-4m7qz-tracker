/* ===========================================================================
   QUIZ BANK — sourced from YOUR ROTC advance sheets & TCs
   ---------------------------------------------------------------------------
   Each question lists its source doc in the explanation so you can verify.
   ⚠️ I (the AI) transcribed these from your course PDFs and may have made
   errors. ALWAYS confirm against the original advance sheet / TC / AR and
   your cadre before relying on any answer for graded work.
   To add: copy a {q,a,c,e} block. c = index (0-3) of the correct answer.
   =========================================================================== */
window.QUIZ_BANK = {
  values: {
    name: "Army Values & Warrior Ethos",
    icon: "🎖️",
    pass: 0.8,
    questions: [
      {q:"How many Army Values are there?", a:["5","6","7","8"], c:2, e:"Seven, forming the acronym LDRSHIP. (AS – Seven Army Values & Warrior Ethos / ADP 6-22)"},
      {q:"What does LDRSHIP stand for, in order?", a:["Loyalty, Duty, Respect, Selfless service, Honor, Integrity, Personal courage","Leadership, Duty, Respect, Service, Honor, Integrity, Pride","Loyalty, Discipline, Respect, Service, Honesty, Integrity, Patriotism","Loyalty, Duty, Resilience, Selfless service, Humility, Integrity, Pride"], c:0, e:"Loyalty, Duty, Respect, Selfless service, Honor, Integrity, Personal courage. (ADP 6-22)"},
      {q:"The first order of loyalty is to:", a:["Your unit","Your commander","The U.S. Constitution","Your fellow Soldiers"], c:2, e:"Loyalty is first to the Constitution and the ideals upon which it is based. (AS – Army Values)"},
      {q:"'Selfless service' means:", a:["Doing only your job","Putting welfare of the nation, Army, and subordinates before your own","Volunteering off-duty","Never asking for help"], c:1, e:"Put the welfare of the nation, the Army, and your subordinates before your own. (ADP 6-22)"},
      {q:"The three attribute categories of an Army leader are:", a:["Character, presence, intellect","Body, mind, spirit","Skill, will, knowledge","Tactics, technique, procedure"], c:0, e:"Character, presence, and intellect. (ADP 6-22, Ch.2)"},
      {q:"How many tenets make up the Warrior Ethos?", a:["3","4","5","7"], c:1, e:"Four lines. (AS – Warrior Ethos)"},
      {q:"Which is NOT one of the Warrior Ethos tenets?", a:["I will always place the mission first","I will never accept defeat","I will never quit","I will always follow orders without question"], c:3, e:"The four: mission first, never accept defeat, never quit, never leave a fallen comrade. (AS – Warrior Ethos)"},
      {q:"What is the only way to change character, per the doctrine?", a:["Counseling alone","Education alone","Modifying deeply held values","Following regulations"], c:2, e:"Modifying deeply held values is the only way to change character. (ADP 6-22, Ch.2)"},
      {q:"Embracing the Army Values is described as:", a:["Optional for officers","The hallmark of being an Army professional","Only for NCOs","A wartime requirement"], c:1, e:"It is the hallmark of being an Army professional. (AS – Army Values)"},
    ]
  },
  usarmy: {
    name: "The US Army & Organization",
    icon: "🇺🇸",
    pass: 0.8,
    questions: [
      {q:"In what year was the U.S. Army established?", a:["1775","1776","1789","1812"], c:0, e:"14 June 1775. (AS – The US Army)"},
      {q:"The Army's motto is:", a:["This We'll Defend","Always Ready","Of the Troops, For the Troops","Army Strong"], c:0, e:"'This We'll Defend.' (AS – The US Army)"},
      {q:"The three components of the Army are:", a:["Active, Reserve, National Guard","Infantry, Armor, Artillery","Land, Air, Sea","Officer, Warrant, Enlisted"], c:0, e:"Regular Army (Active), U.S. Army Reserve, Army National Guard. (AS – The US Army)"},
      {q:"Who is the civilian head of the Department of the Army?", a:["Chief of Staff of the Army","Secretary of the Army","Sergeant Major of the Army","Secretary of Defense"], c:1, e:"The Secretary of the Army. (AS – The US Army)"},
      {q:"The senior military officer in the Army is the:", a:["Secretary of the Army","Chief of Staff of the Army","SMA","Chairman of the Joint Chiefs"], c:1, e:"The Chief of Staff of the Army. (AS – The US Army)"},
      {q:"The Commander-in-Chief of the Armed Forces is the:", a:["Secretary of Defense","President","Chairman of the Joint Chiefs","CSA"], c:1, e:"The President of the United States. (AS – The US Army)"},
      {q:"'Chain of command' is:", a:["The supply route","The succession of leaders through which authority and orders pass","The unit's history","The duty roster"], c:1, e:"The line of authority and responsibility along which orders pass. (AS – The US Army)"},
      {q:"Which is the correct echelon order, smallest to largest?", a:["Squad, platoon, company, battalion","Platoon, squad, company, battalion","Squad, company, platoon, battalion","Team, company, squad, platoon"], c:0, e:"Team → squad → platoon → company → battalion → brigade → division. (AS – Tactics)"},
    ]
  },
  customs: {
    name: "Customs & Courtesies",
    icon: "🫡",
    pass: 0.8,
    questions: [
      {q:"At how many paces does a subordinate initiate the hand salute to an officer?", a:["Three paces","Six paces","Ten paces","Two paces"], c:1, e:"Salute is initiated at about six paces and terminated upon acknowledgment. (TC 3-21.5, Ch.4)"},
      {q:"Whom do you salute?", a:["NCOs only","Commissioned and warrant officers","Everyone senior to you","Only general officers"], c:1, e:"Render salutes to commissioned and warrant officers. (TC 3-21.5)"},
      {q:"Reveille is the bugle call that:", a:["Signals mealtime","Signals troops to awaken / coincides with raising the Colors","Lowers the flag in the evening","Signals lights out"], c:1, e:"Reveille signals morning roll call and coincides with raising the national Color. (TC 3-21.5, Ch.1)"},
      {q:"Retreat is the ceremony that:", a:["Raises the flag in the morning","Pays honors to the national flag when lowered in the evening","Signals a tactical withdrawal","Begins a parade"], c:1, e:"Retreat pays honors to the flag when it is lowered. (TC 3-21.5)"},
      {q:"Our national anthem officially became 'The Star-Spangled Banner' in what year?", a:["1814","1900","1931","1949"], c:2, e:"By law on 3 March 1931 (Title 36, U.S. Code). (TC 3-21.5, Ch.1)"},
      {q:"'To the Color' is played:", a:["Before Reveille","Immediately after Retreat","At mess call","Only on holidays"], c:1, e:"Played immediately after Retreat. (TC 3-21.5)"},
      {q:"Mess call is the bugle call that signals:", a:["Wake-up","Mealtime","Formation","Lights out"], c:1, e:"Mess call signals mealtime. (TC 3-21.5, Ch.1)"},
      {q:"The primary purpose of drill is to:", a:["Look impressive at parades","Move units orderly, instill discipline, and develop leaders","Pass time in garrison","Test physical fitness"], c:1, e:"Drill moves units orderly, aids disciplinary training, and develops Soldiers in commanding troops. (TC 3-21.5, Ch.1)"},
    ]
  },
  leadership: {
    name: "Army Leadership",
    icon: "⭐",
    pass: 0.8,
    questions: [
      {q:"The Army leadership model is summarized as:", a:["Be, Know, Do","Plan, Prepare, Execute","Shoot, Move, Communicate","Ready, Aim, Fire"], c:0, e:"Be (character), Know (competence), Do (action). (ADP 6-22)"},
      {q:"Army leadership influences people by providing purpose, direction, and:", a:["Discipline","Motivation","Resources","Orders"], c:1, e:"Purpose, direction, and motivation. (ADP 6-22)"},
      {q:"The three leader competency categories are:", a:["Leads, Develops, Achieves","Plans, Leads, Reports","Trains, Fights, Wins","Knows, Does, Teaches"], c:0, e:"Leads, Develops, Achieves. (ADP 6-22)"},
      {q:"A leader's character is their true nature guided by their:", a:["Rank","Conscience","Training","Orders"], c:1, e:"True nature guided by conscience, shaping moral attitudes and actions. (ADP 6-22, Ch.2)"},
      {q:"A leader's personal reputation is:", a:["What others view as their character","Their official record","Their rank and awards","Set by their commander"], c:0, e:"Reputation is what others view as character. (ADP 6-22)"},
      {q:"Officers primarily focus on (vs. NCOs):", a:["Individual drill","The mission, planning, and the 'what/why'","Equipment maintenance","Barracks inspections"], c:1, e:"Officers command, plan, and decide; NCOs execute and train. (AS – Army Leadership)"},
    ]
  },
  profession: {
    name: "The Army Profession",
    icon: "🏛️",
    pass: 0.8,
    questions: [
      {q:"The Army Profession is built on the foundation of:", a:["Trust","Pay","Rank","Tradition alone"], c:0, e:"Trust is the bedrock of the Army Profession. (ADP 1 / AS – The Army Profession)"},
      {q:"An Army professional meets certification criteria in character, competence, and:", a:["Commitment","Courage","Conduct","Compliance"], c:0, e:"Character, competence, and commitment. (ADP 1)"},
      {q:"The two communities of the Army Profession are:", a:["The profession of arms and the Army Civilian Corps","Active and Reserve","Officers and NCOs","CONUS and OCONUS"], c:0, e:"The profession of arms and the Army Civilian Corps. (ADP 1)"},
      {q:"The essential characteristics of the Army Profession include military expertise, honorable service, stewardship, and:", a:["Esprit de corps","Discipline","Loyalty","Tradition"], c:0, e:"Military expertise, honorable service, stewardship, esprit de corps. (ADP 1)"},
      {q:"Esprit de Corps refers to:", a:["The winning spirit and common morale of the Army","A formation","An award","A regulation"], c:0, e:"The winning spirit / common spirit of the profession. (ADP 1)"},
    ]
  },
  landnav: {
    name: "Land Navigation & Maps",
    icon: "🧭",
    pass: 0.8,
    questions: [
      {q:"On a military map, blue represents:", a:["Vegetation","Water features","Man-made objects","Contours"], c:1, e:"Blue = water. (AS – Basic Map Reading)"},
      {q:"Green on a military map represents:", a:["Water","Vegetation","Elevation","Roads"], c:1, e:"Green = vegetation. (AS – Basic Map Reading)"},
      {q:"Brown on a military map typically depicts:", a:["Water","Vegetation","Relief features / contour lines","Boundaries"], c:2, e:"Brown shows relief/elevation (contours). (AS – Basic Map Reading)"},
      {q:"Contour lines spaced close together indicate:", a:["Flat terrain","Steep terrain","A water source","A road"], c:1, e:"Close contours = steep slope. (AS – Basic Map Reading)"},
      {q:"The three norths on a military map are:", a:["True, magnetic, grid","North, true, polar","Magnetic, solar, grid","Map, compass, GPS"], c:0, e:"True, magnetic, and grid north. (AS – Basic Land Navigation)"},
      {q:"The grid-magnetic (G-M) angle converts between:", a:["True and grid azimuths","Grid and magnetic azimuths","Two grid squares","Mils and degrees"], c:1, e:"Converts grid and magnetic azimuths. (AS – Basic Land Navigation)"},
      {q:"When reading grid coordinates, you:", a:["Read up, then right","Read right, then up","Read left, then down","Read diagonally"], c:1, e:"'Read right, then up' (easting before northing). (AS – Basic Map Reading)"},
      {q:"A six-digit grid coordinate locates a point to within:", a:["10 meters","100 meters","1,000 meters","1 meter"], c:1, e:"6-digit = 100m (4=1000m, 8=10m, 10=1m). (AS – Basic Land Navigation)"},
      {q:"A full circle on a military compass equals:", a:["360 mils","3,600 mils","6,400 mils","1,000 mils"], c:2, e:"6,400 mils = 360 degrees. (AS – Basic Land Navigation)"},
      {q:"To find a back azimuth when the azimuth is under 180°, you:", a:["Subtract 180","Add 180","Add 360","Subtract from 360"], c:1, e:"Add 180 if under 180; subtract 180 if 180 or more. (AS – Basic Land Navigation)"},
    ]
  },
  firstaid: {
    name: "Basic First Aid",
    icon: "🩹",
    pass: 0.8,
    questions: [
      {q:"The leading cause of preventable death on the battlefield is:", a:["Airway obstruction","Extremity hemorrhage (bleeding)","Infection","Hypothermia"], c:1, e:"Massive extremity hemorrhage is the leading preventable cause. (AS – Basic First Aid / TCCC)"},
      {q:"The TCCC priority memory aid is:", a:["ABC","MARCH","RICE","SALUTE"], c:1, e:"MARCH. (AS – Basic First Aid)"},
      {q:"In MARCH, the first 'M' stands for:", a:["Movement","Massive hemorrhage","Medication","Monitoring"], c:1, e:"Massive hemorrhage is addressed first. (AS – Basic First Aid)"},
      {q:"For life-threatening extremity bleeding, the first-line treatment is:", a:["A pressure dressing","A tourniquet","Elevation","An ice pack"], c:1, e:"Apply a tourniquet. (AS – Basic First Aid)"},
      {q:"A tourniquet should be placed:", a:["Directly on the wound","High and tight above the wound, not on a joint","Below the wound","On the nearest joint"], c:1, e:"High and tight above the wound, not over a joint. (AS – Basic First Aid)"},
      {q:"The 'A' in MARCH refers to:", a:["Airway","Assessment","Ambulation","Antibiotics"], c:0, e:"Airway. (AS – Basic First Aid)"},
      {q:"The 'H' in MARCH refers to:", a:["Hydration","Hypothermia prevention","Hospital","Heart rate"], c:1, e:"Hypothermia prevention / head injury. (AS – Basic First Aid)"},
    ]
  },
  tactics: {
    name: "Tactics, Formations & Battle Drills",
    icon: "🪖",
    pass: 0.8,
    questions: [
      {q:"A fire team typically consists of how many Soldiers?", a:["2","4","9","12"], c:1, e:"A fire team is usually 4. (AS – Team & Squad Tactics I)"},
      {q:"An infantry squad typically consists of how many Soldiers?", a:["4","6","9","12"], c:2, e:"Typically 9 (two fire teams + squad leader). (AS – Team & Squad Tactics)"},
      {q:"The three movement techniques are:", a:["Traveling, traveling overwatch, bounding overwatch","Walk, jog, run","File, wedge, line","Crawl, walk, run"], c:0, e:"Traveling, traveling overwatch, bounding overwatch. (AS – Formations & Movement)"},
      {q:"Which movement technique is used when enemy contact is expected?", a:["Traveling","Traveling overwatch","Bounding overwatch","Administrative march"], c:2, e:"Bounding overwatch — contact expected. (AS – Formations & Movement)"},
      {q:"The two types of bounding are:", a:["Successive and alternate","Left and right","Fast and slow","High and low"], c:0, e:"Successive and alternate bounds. (AS – Formations & Movement)"},
      {q:"'React to Contact' begins with:", a:["Call for fire","Return fire and take cover","Withdraw","Request resupply"], c:1, e:"Return fire / take cover is the immediate action. (AS – Battle Drills)"},
      {q:"A patrol sent to gather information without being detected is a:", a:["Combat patrol","Reconnaissance patrol","Ambush patrol","Raid"], c:1, e:"Recon patrol gathers info; combat patrols fight. (AS – Basic Patrolling)"},
      {q:"The two categories of patrols are:", a:["Recon and combat","Day and night","Mounted and dismounted","Fast and deliberate"], c:0, e:"Reconnaissance and combat patrols. (AS – Basic Patrolling)"},
    ]
  },
  opords: {
    name: "OPORDs & Mission Command",
    icon: "📋",
    pass: 0.8,
    questions: [
      {q:"How many paragraphs are in a standard OPORD?", a:["3","4","5","8"], c:2, e:"Five: Situation, Mission, Execution, Sustainment, Command & Signal. (AS – OPORDs)"},
      {q:"The five OPORD paragraphs in order are:", a:["Situation, Mission, Execution, Sustainment, Command & Signal","Mission, Situation, Execution, Logistics, Command","Intro, Body, Execution, Support, Close","Who, What, When, Where, Why"], c:0, e:"S-M-E-S-C. (AS – OPORDs)"},
      {q:"The MISSION paragraph (para 2) is built on the:", a:["Five W's (who, what, when, where, why)","METT-TC","OAKOC","Five paragraphs"], c:0, e:"Who, what, when, where, why (purpose). (AS – OPORDs)"},
      {q:"METT-TC stands for:", a:["Mission, Enemy, Terrain/weather, Troops, Time available, Civil considerations","Mission, Execution, Tactics, Troops, Time, Command","Movement, Enemy, Terrain, Troops, Timing, Communication","Mission, Equipment, Terrain, Tactics, Time, Command"], c:0, e:"Mission, Enemy, Terrain & weather, Troops, Time available, Civil considerations. (AS – Mission Command)"},
      {q:"OAKOC (terrain analysis) stands for:", a:["Observation & fields of fire, Avenues of approach, Key terrain, Obstacles, Cover & concealment","Open, Action, Key, Obstacle, Concealment","Observe, Assess, Know, Operate, Command","Obstacles, Approach, Key terrain, Observation, Cover"], c:0, e:"Observation/fields of fire, Avenues of approach, Key terrain, Obstacles, Cover & concealment. (AS – Tactics)"},
      {q:"How many steps are in the Troop Leading Procedures?", a:["5","6","7","8"], c:3, e:"Eight steps. (AS – Mission Command / TLP)"},
      {q:"The first step of TLP is:", a:["Receive the mission","Issue a WARNO","Make a tentative plan","Conduct recon"], c:0, e:"Step 1: Receive the mission. (AS – TLP)"},
      {q:"The second step of TLP is:", a:["Make a tentative plan","Issue a warning order (WARNO)","Initiate movement","Complete the plan"], c:1, e:"Step 2: Issue a WARNO. (AS – TLP)"},
      {q:"'Commander's intent' provides subordinates with:", a:["Exact step-by-step orders","Purpose, key tasks, and desired end state","The duty roster","Supply figures"], c:1, e:"Enables disciplined initiative toward the end state. (AS – Mission Command)"},
      {q:"Mission command emphasizes:", a:["Centralized, scripted control","Decentralized execution guided by commander's intent","No planning","Detailed micromanagement"], c:1, e:"Disciplined initiative within commander's intent. (AS – Mission Command)"},
    ]
  },
  cyber: {
    name: "Cyber Branch (17-series)",
    icon: "💻",
    pass: 0.8,
    questions: [
      {q:"The Cyber Branch plans, integrates, synchronizes, and executes:", a:["Logistics and supply","Cyberspace and electromagnetic warfare operations","Field artillery fires","Aviation operations"], c:1, e:"Cyberspace operations (CO) and electromagnetic warfare (EW). (Cyber Branch sheet / DA PAM 600-3)"},
      {q:"The three interrelated missions of Cyberspace Operations (CO) are:", a:["DCO, OCO, and DODIN operations","Attack, defend, retreat","Recon, raid, ambush","Plan, prepare, execute"], c:0, e:"Defensive CO, Offensive CO, DoD Information Network operations. (Cyber Branch sheet)"},
      {q:"What clearance must Cyber Officers obtain and maintain?", a:["SECRET","TOP SECRET with SCI access (TS/SCI)","CONFIDENTIAL","No clearance required"], c:1, e:"TS/SCI plus a favorable special background investigation; U.S. citizen with no other citizenships. (Cyber Branch sheet)"},
      {q:"The Cyber Warfare Officer AOC is:", a:["17A","17B","17D","25A"], c:0, e:"17A — Cyber Warfare Officer. (Cyber Branch sheet)"},
      {q:"The Cyber Electromagnetic Warfare Officer (CEWO) AOC is:", a:["17A","17B","17D","17C"], c:1, e:"17B — Cyber Electromagnetic Warfare Officer. (Cyber Branch sheet)"},
      {q:"The Cyber Capabilities Development Officer AOC is:", a:["17A","17B","17D","17E"], c:2, e:"17D — Cyber Capabilities Development Officer (software/hardware solutions). (Cyber Branch sheet)"},
      {q:"Cyber lieutenants attend which initial course for AOC 17A?", a:["CCC","CyBOLC (Cyber Basic Officer Leader Course)","WOBC","Ranger School"], c:1, e:"Cyber Basic Officer Leader Course (CyBOLC). (Cyber Branch sheet)"},
      {q:"Which AOC must Cyber Officers FIRST qualify in, starting at lieutenant?", a:["17A","17B","17D","17C"], c:0, e:"Must first qualify as 17A. (Cyber Branch sheet)"},
      {q:"Electromagnetic Warfare includes electromagnetic attack, electromagnetic protection, and:", a:["Electromagnetic support","Electromagnetic recon","Electromagnetic logistics","Electromagnetic command"], c:0, e:"EA, EP, and electromagnetic support (ES). (Cyber Branch sheet)"},
      {q:"The Cyber Branch proponent/school is located at:", a:["Fort Benning, GA","Fort Gordon (Cyber CoE), GA","Fort Sill, OK","Fort Rucker, AL"], c:1, e:"U.S. Army Cyber School, Fort Gordon, GA. (Cyber Branch sheet)"},
      {q:"Cyber is described as the only branch specifically designed to:", a:["Maneuver armor formations","Engage adversaries directly within the cyberspace domain and EMS battlespace","Provide artillery support","Conduct air assault"], c:1, e:"The only branch designed to engage adversaries directly in cyberspace and the EMS. (Cyber Branch sheet)"},
    ]
  },
  weapons: {
    name: "Weapons (M4 / M9-M17 / M249)",
    icon: "🔧",
    pass: 0.8,
    questions: [
      {q:"The M4/M16 is best described as a:", a:["7.62mm gas-operated rifle","5.56mm magazine-fed, gas-operated, air-cooled, shoulder-fired weapon","9mm semiautomatic pistol","Belt-fed machine gun"], c:1, e:"5.56mm, magazine-fed, gas-operated, air-cooled, shoulder-fired. (PMI M16/M4, TC 3-22.9)"},
      {q:"The M4 fires in which modes?", a:["Semiautomatic only","Semiautomatic and three-round burst/automatic","Fully automatic only","Single-shot only"], c:1, e:"Semiautomatic and three-round burst/automatic depending on variant. (TC 3-22.9)"},
      {q:"In weapon status colors, 'GREEN' means:", a:["Loaded and ready","Magazine removed, chamber empty, selector on SAFE","Magazine in, chamber loaded","Bolt forward on a loaded round"], c:1, e:"Green = magazine removed, chamber empty, SAFE ('Green and Clear'). (TC 3-22.9)"},
      {q:"In weapon status colors, 'RED' means:", a:["Weapon is clear","Filled magazine in well, chamber loaded, bolt forward, on SAFE","Magazine out","Bolt locked to the rear, empty"], c:1, e:"Red = filled magazine, chamber loaded, bolt forward, on SAFE. (TC 3-22.9)"},
      {q:"'AMBER' weapon status means:", a:["Chamber empty, no magazine","Filled magazine in well, bolt forward on an EMPTY chamber, on SAFE","Fully loaded and firing","Disassembled"], c:1, e:"Amber = filled magazine in the well, bolt forward on an empty chamber, on SAFE. (TC 3-22.9)"},
      {q:"The M249 SAW is a:", a:["5.56mm gas-operated, belt-fed, air-cooled, fully automatic weapon firing from the open-bolt position","7.62mm bolt-action rifle","9mm pistol","Single-shot grenade launcher"], c:0, e:"5.56mm, gas-operated, belt-fed, air-cooled, full-auto, fires from open bolt. (TC 3-22.249)"},
      {q:"The M249 SUSTAINED rate of fire is approximately:", a:["50 rounds/min, 6-9 round bursts, barrel change every 10 min","850 rounds/min continuous","200 rounds/min","12-15 rounds/min"], c:0, e:"Sustained ≈50 rds/min, 6-9 round bursts, barrel change every 10 minutes. (TC 3-22.249)"},
      {q:"The M249 CYCLIC rate of fire is approximately:", a:["50 rounds/min","100 rounds/min","850 rounds/min, barrel change every minute","1,500 rounds/min"], c:2, e:"Cyclic ≈850 rds/min, barrel change every minute. (TC 3-22.249)"},
      {q:"The first rule of weapons safety is to treat every weapon as if it is:", a:["Unloaded","Loaded","Broken","Clean"], c:1, e:"Always treat every weapon as if it is loaded. (PMI / TC 3-22.9)"},
      {q:"M4 'Rapid Semiautomatic' fire is approximately:", a:["12-15 rounds/min","~45 rounds/min","100 rounds/min","850 rounds/min"], c:1, e:"Rapid semi ≈45 rds/min; slow semi is 12-15 rds/min. (TC 3-22.9)"},
    ]
  },
  warfighting: {
    name: "Warfighting Functions",
    icon: "⚔️",
    pass: 0.8,
    questions: [
      {q:"How many elements of combat power are there?", a:["Six","Seven","Eight","Five"], c:2, e:"Eight: leadership, information, C2, movement & maneuver, intelligence, fires, sustainment, protection. (AS – Sustainment / ADP 3-0)"},
      {q:"Which is NOT a warfighting function?", a:["Fires","Sustainment","Logistics","Intelligence"], c:2, e:"WfFs: C2, movement & maneuver, intelligence, fires, sustainment, protection (logistics is part of sustainment). (ADP 3-0)"},
      {q:"The Movement and Maneuver warfighting function:", a:["Moves and employs forces to achieve a position of relative advantage","Provides supplies and services","Gathers information on the enemy","Defends against air attack"], c:0, e:"Moves/employs forces for positional advantage; direct fire and close combat are inherent. (AS – Movement and Maneuver)"},
      {q:"The Protection warfighting function primarily:", a:["Destroys enemy armor","Prevents or mitigates threats/hazards to preserve combat power","Resupplies the force","Provides indirect fire"], c:1, e:"Preserves combat power and enables freedom of action/survivability. (AS – Protection)"},
      {q:"The Fires warfighting function exists to:", a:["Move forces","Create effects to achieve the commander's objectives","Provide medical care","Manage personnel"], c:1, e:"Creates lethal/nonlethal effects to achieve the commander's objectives. (AS – Fires)"},
      {q:"The Intelligence warfighting function provides:", a:["Supplies and transport","Understanding of the threat, terrain, weather, and civil considerations","Air defense","Direct fire"], c:1, e:"Facilitates understanding of the threat and operational environment. (AS – Intelligence)"},
      {q:"The Sustainment warfighting function includes logistics, financial management, personnel services, and:", a:["Health service support","Fire support","Air defense","Cyber operations"], c:0, e:"Logistics, financial management, personnel services, health service support. (AS – Sustainment)"},
      {q:"Warfighting functions are best described as:", a:["The physical means commanders use to execute operations","Branch insignia","Types of formations","Ranks"], c:0, e:"They organize critical capabilities for commanders/staffs. (AS – Fires)"},
    ]
  },
  comms: {
    name: "Communication Process",
    icon: "📡",
    pass: 0.8,
    questions: [
      {q:"The communication process involves a sender, a message, a medium/channel, and a:", a:["Receiver","Regulation","Radio","Report"], c:0, e:"Sender → message → medium → receiver, with feedback. (AS – Communication Process)"},
      {q:"'Feedback' in communication is:", a:["The receiver's response confirming understanding","Noise","The channel","The message"], c:0, e:"Feedback closes the loop and confirms understanding. (AS – Communication Process)"},
      {q:"'Noise' in communication refers to:", a:["Loud sounds only","Anything that interferes with or distorts the message","The medium","Feedback"], c:1, e:"Any interference (physical, semantic, psychological) that distorts the message. (AS – Communication Process)"},
      {q:"Active listening is primarily the responsibility of the:", a:["Sender","Receiver","Channel","Commander only"], c:1, e:"The receiver practices active listening to decode accurately. (AS – Communication Process)"},
      {q:"Effective leader communication should be:", a:["Vague to allow flexibility","Clear, concise, and audience-appropriate","One-way only","As long as possible"], c:1, e:"Clear, concise, audience-appropriate for shared understanding. (AS – Communication Process)"},
    ]
  },
  history: {
    name: "American Military History",
    icon: "📜",
    pass: 0.8,
    questions: [
      {q:"The Continental Army was established in:", a:["1775","1776","1781","1789"], c:0, e:"14 June 1775 by the Continental Congress. (American Military History v1)"},
      {q:"Who was appointed commander of the Continental Army in 1775?", a:["Thomas Jefferson","George Washington","Benjamin Franklin","Nathanael Greene"], c:1, e:"George Washington. (American Military History v1)"},
      {q:"The opening battle of the Revolution (1775) was at:", a:["Bunker Hill","Lexington and Concord","Saratoga","Yorktown"], c:1, e:"Lexington and Concord, April 1775. (American Military History v1)"},
      {q:"The turning-point victory credited with bringing France into the Revolution was:", a:["Trenton","Saratoga","Valley Forge","Camden"], c:1, e:"Saratoga (1777). (American Military History v1)"},
      {q:"Baron von Steuben is best known for:", a:["Funding the war","Training and drilling the Continental Army at Valley Forge","Negotiating with France","Commanding the British"], c:1, e:"Instilled discipline and drill at Valley Forge (1777-78). (American Military History v1)"},
      {q:"The Revolutionary War effectively ended with the British surrender at:", a:["Yorktown (1781)","Saratoga (1777)","Boston (1776)","Trenton (1776)"], c:0, e:"Cornwallis surrendered at Yorktown, 1781. (American Military History v1)"},
    ]
  },
  branches: {
    name: "Know Your Branches",
    icon: "🎗️",
    pass: 0.8,
    questions: [
      {q:"Which is the Army's only maneuver branch whose mission is to 'close with and destroy the enemy'?", a:["Field Artillery","Infantry","Engineer","Signal"], c:1, e:"Infantry — close with and destroy the enemy by fire and movement. (Branch Orientation IN/AR/AV/SF)"},
      {q:"The Transportation Branch is known as the:", a:["King of Battle","Spearhead of Logistics","Queen of Battle","Eyes of the Army"], c:1, e:"'Spearhead of Logistics' — 'Nothing happens until something moves.' (Branch Orientation – Sustainment)"},
      {q:"Field Artillery is traditionally nicknamed the:", a:["King of Battle","Queen of Battle","Spearhead","Backbone"], c:0, e:"Field Artillery = 'King of Battle'; Infantry = 'Queen of Battle.' (common Army knowledge / branch orientation)"},
      {q:"Army Aviation is a branch that:", a:["Provides a maneuver advantage through air operations","Handles all supply","Manages personnel records","Conducts cyber operations"], c:0, e:"Provides a maneuver advantage to Army and Joint commanders. (Branch Orientation – Aviation)"},
      {q:"Which are MANEUVER branches?", a:["Infantry, Armor, Aviation (and Special Forces)","Finance, AG, Quartermaster","Signal, Cyber, MI","Engineer, Chemical, MP"], c:0, e:"Infantry, Armor, Aviation, Special Forces. (Branch Orientation IN/AR/AV/SF)"},
      {q:"The Adjutant General (AG) branch primarily handles:", a:["Indirect fires","Personnel and human resources support","Bridging operations","Air defense"], c:1, e:"AG provides personnel/HR support. (Branch Orientation – Sustainment branches)"},
      {q:"The Cyber Branch's AOCs are in which series?", a:["11-series","17-series","25-series","35-series"], c:1, e:"17-series (17A/17B/17D). (Branch Orientation FA/AD/CY/PO)"},
    ]
  },
  regs: {
    name: "Regulations & Policy",
    icon: "📕",
    pass: 0.8,
    questions: [
      {q:"Which regulation is the Army Command Policy?", a:["AR 600-20","AR 600-9","AR 670-1","AR 350-1"], c:0, e:"AR 600-20, Army Command Policy. (AR 600-20)"},
      {q:"The SHARP program is governed primarily by:", a:["AR 600-20 / AR 600-52","AR 670-1","AR 27-10","AR 25-2"], c:0, e:"SHARP falls under AR 600-20, program detail in AR 600-52. (AR 600-52)"},
      {q:"AR 600-32 governs:", a:["Wear of the uniform","Conduct between Soldiers of different grades","Physical fitness","Awards"], c:1, e:"Conduct Between Soldiers of Different Grades (inappropriate relationships). (AR 600-32)"},
      {q:"A relationship between cadre/trainer and a trainee is:", a:["Always permitted","Prohibited as an inappropriate/unprofessional relationship","Encouraged","Allowed off-duty"], c:1, e:"Prohibited; see DD Form 2983 acknowledgment. (AR 600-32 / DD 2983)"},
      {q:"The chain of command and NCO support channel are addressed primarily in:", a:["AR 600-20","AR 670-1","AR 600-9","AR 350-1"], c:0, e:"AR 600-20. (AR 600-20)"},
      {q:"SHARP's two reporting options for victims are:", a:["Restricted and Unrestricted","Verbal and written","Formal and informal","Open and closed"], c:0, e:"Restricted (confidential) and Unrestricted reporting. (AR 600-20 / SHARP)"},
    ]
  }
};
